// Entry shim — supaya panel/host yang default lookup ke `./index.js` tetap jalan.
// Logika sebenarnya ada di src/index.js
import './src/index.js';
